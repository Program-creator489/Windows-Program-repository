polybiezer.exe non safety version is very dangerous and is capable of deleting all of your Data and overwriting the MBR
Credit's to Program-creator489 from GitHub making this